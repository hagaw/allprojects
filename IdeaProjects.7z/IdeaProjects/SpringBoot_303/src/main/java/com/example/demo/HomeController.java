package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.BindResult;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.annotation.RequestScope;
import javax.jws.WebParam;
import javax.validation.Valid;

//===============================================

@Controller
public class HomeController {
    @Autowired
    CourseRepository CourseRepository;


    @RequestMapping("/")

    public String listCourses(Model model) {
        model.addAttribute("courses", CourseRepository.findAll());
        return "list";
    }

    @GetMapping("/add")

    public String courseForm(Model model) {
        model.addAttribute("course", new Course());
        return "courseform";

    }

    @PostMapping("/process")
    public String processForm(@Valid Course course,
                              BindingResult resualt) {
        if (resualt.hasErrors()) {

            return "courseform";

        }

        CourseRepository.save(course);
        return "redirect:/";
    }

    @RequestMapping("/detail/{id}")
    public String showCourse(@PathVariable("id") long id, Model model) {
        model.addAttribute("course", CourseRepository.findById(id));
        return "courseform";

    }

    @RequestMapping("/update/{id}")
    public String updateCourse(@PathVariable("id") long id, Model model) {
        model.addAttribute("course", CourseRepository.findById(id));
        return "show";
    }

    @RequestMapping("/delete/{id}")
    public String delCourse(@PathVariable("id") long id, Model model) {
        model.addAttribute("course", CourseRepository.findById(id));
        return "redirect";


    }
}