package com.example.demo;


@Entity

public class Person {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)

}
