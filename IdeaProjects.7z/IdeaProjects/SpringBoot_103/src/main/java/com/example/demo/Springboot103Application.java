package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot103Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot103Application.class, args);
	}
}
