package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import sun.awt.ModalExclude;

@Controller
public class HomeControler {
    @GetMapping("/addCatagory")
    public String getCatagoryForm(Model model){


    }

}
