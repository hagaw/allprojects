package com.example.demo;

import javax.persistence.*;
import java.util.Set;

@Entity

public class Catagory {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    //one car belong to one catagrouy
    //one catagory contain how many car ==many car
    @OneToMany(mappedBy = "catagory",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    private Set<Car> cars;


    public Long getId() {
        return id;

    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Car> getCars() {
        return cars;
    }

    public void setCars(Set<Car> cars) {
        this.cars = cars;
    }
}

