package com.example.demo;

import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.jws.WebParam;
import javax.validation.Valid;
import java.util.HashSet;
import java.util.Set;

@Controller

public class HomeController {

    @Autowired
    DepartmentRepository departmentRepository;
    @RequestMapping("/")

    public String index(Model model){
        Department department=new Department();

        Employee employee=new Employee();
        Set<Employee>employees=new HashSet<Employee>();

        employees.add(employee);
        department.setEmplyee(employees);

        departmentRepository.save(department);

        model.addAttribute("departments",departmentRepository.findAll());
        return "list";




    }

    @PostMapping("/add")

    public String departmentForm(Model model){
        model.addAttribute("department",new Department());
        return "departmentform";
        }

        @PostMapping("/process")
    public String processForm(@Valid Department department,BindingResult result){
        if(result.hasErrors()) {
            return "departmentform";
        }
        departmentRepository.save(department);
        return "redirect:/";
        }

    @RequestMapping("/detail/{id}")
    public String showDepartment(@PathVariable("id") long id, Model model){
        model.addAttribute("department", departmentRepository.findById(id).get());
        return "show";
    }

    @RequestMapping("/update/{id}")
    public String updateDepartment(@PathVariable("id") long id, Model model) {
        model.addAttribute("department", departmentRepository.findById(id).get());
        return "departmentform";
    }

    @RequestMapping("/delete/{id}")
    public String deleteDepartment(@PathVariable("id") long id) {
        departmentRepository.deleteById(id);
            return "redirect:/";
        }
    }






