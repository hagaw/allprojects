package com.example.demo;

import javax.persistence.*;
import java.util.Set;

@Entity

public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long id;
    public String departmentName;
    @OneToMany(mappedBy = "department",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    public Set<Employee> emplyee;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Set<Employee> getEmplyee() {
        return emplyee;
    }

    public void setEmplyee(Set<Employee> emplyee) {
        this.emplyee = emplyee;
    }
}
