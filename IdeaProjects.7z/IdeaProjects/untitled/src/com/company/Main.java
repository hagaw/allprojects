package com.company;

import jdk.nashorn.internal.ir.ReturnNode;

import java.util.ArrayList;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        // write your code here
    }

    public static ArrayList<String> getRandomItem(ArrayList<String> items) {
        Random rand=new Random();
        int rn=rand.nextInt(items.size());

        return items;


        }

  public static ArrayList<String>getColor(ArrayList<String>colors){


      return colors;
  }
  public static ArrayList<String>GetDrinks(ArrayList<String>drinks){

        return drinks;
  }

  public static String loop(){


  }

    }

