package com.example.argaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArgawApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArgawApplication.class, args);
	}
}
