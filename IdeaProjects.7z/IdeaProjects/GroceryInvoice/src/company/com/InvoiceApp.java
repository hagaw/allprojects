package company.com;


import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class InvoiceApp {


    public static void main(String[] args) {

        Random rn = new Random();


        double totalPrice = 0;
        double totalInvoice = 0;

        String stop = "";
        String userInputItemName = "";
        Scanner sc = new Scanner(System.in);


        ArrayList<Invoice> myInvoice = new ArrayList<Invoice>();
        int userInputQuantit = rn.nextInt(10);

        do {
            System.out.println("pleas enter the Item Name");
            userInputItemName = sc.next();

            System.out.println("enter the price");

            double userInputPrice = sc.nextDouble();

            totalPrice = userInputQuantit * userInputPrice;
            totalInvoice = totalInvoice + totalPrice;

            myInvoice.add(new Invoice(userInputItemName, userInputPrice, userInputQuantit, totalPrice));

            System.out.println("Do you want to add more invoice ? yes/No");

            stop = sc.next();

        } while (!stop.equalsIgnoreCase("no"));

        System.out.println("Item Name" + "\t" + "Price" + "\t" + "Quantity" + "\t" + "Total");
        System.out.println("======================================");


        for (Invoice invocePrnt : myInvoice) {

            System.out.println(invocePrnt.getItemName() + "\t\t" + invocePrnt.getPrice() + "\t\t" + invocePrnt.getQuantity() + "\t\t" + invocePrnt.getTotalPrice());
        }

        System.out.println("total purchase amount " + "\t" + totalInvoice);
        System.out.println("total purchase items " + myInvoice.size());

//this is the condtion to salute the purchaser for having business with us

        if (totalInvoice > 20) {
            System.out.println("You spend to much");
        } else {
            System.out.println("Thank you for Shopping at my market");
        }
    }
}
