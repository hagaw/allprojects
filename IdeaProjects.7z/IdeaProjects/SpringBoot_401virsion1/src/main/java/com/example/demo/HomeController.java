
package com.example.demo;
        import org.hibernate.validator.constraints.SafeHtml;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
        import org.springframework.security.crypto.password.PasswordEncoder;
        import org.springframework.stereotype.Controller;
        import org.springframework.ui.Model;
        import org.springframework.validation.BindingResult;
        import org.springframework.web.bind.annotation.*;

        import javax.naming.Binding;
        import javax.validation.Valid;
        import javax.xml.crypto.Data;
        import javax.xml.soap.SAAJResult;
        import java.security.Principal;

    @Controller

    public class HomeController {
        @Autowired

        private UserService userService;

        @Autowired
        private PetRepository petRepository;

        @GetMapping("/register")

        public String showRegistrationPage(Model model) {
            model.addAttribute("user", new User());
            return "registration";
        }

        @PostMapping("/register")
        public String processRegistrationPage(@Valid @ModelAttribute("user") User user, BindingResult result, Model model) {
            model.addAttribute("user", user);

            if (result.hasErrors()) {
                return "register";
            } else {
                userService.saveUser(user);
                model.addAttribute("message", "User Account Created");
            }
            return "index";
        }

        //===============================================

//    @RequestMapping("/")
//
//    public String index(){
//        return "index";
//    }

        @RequestMapping("/login")

        public String login() {
            return "login";
        }

        @RequestMapping("/secure")
        public String secure(Principal principal, Model model) {

            User myuser = ((CustomUserDetails)
                    ((UsernamePasswordAuthenticationToken) principal).getPrincipal()).getUser();
            model.addAttribute("myuser", myuser);
            return "secure";

        }

        @RequestMapping("/")
        public String listCourses(Model model) {
            model.addAttribute("pet", petRepository.findAll());
            return "ViewPet";
        }

        @GetMapping("/add")
        public String courseForm(Model model) {
            model.addAttribute("pet", new Pets());
            return "petForm";
        }

        @PostMapping("/process")
        public String processForm(@Valid Pets petes, BindingResult result) {
            if (result.hasErrors()) {
                return "petForm";
            }

            petRepository.save(petes);
            return "redirect:/";
        }

        @RequestMapping("/detail/{id}")
        public String showPets(@PathVariable("id") long id, Model model) {
            model.addAttribute("pet", petRepository.findById(id).get());
            return "show";
        }

        @RequestMapping("/update/{id}")
        public String updatePests(@PathVariable("id") long id, Model model) {
            model.addAttribute("pet", petRepository.findById(id).get());

            return "petForm";
        }

        @RequestMapping("/delete/{id}")
        public String delPets(@PathVariable("id") long id) {
            petRepository.deleteById(id);
            return "redirect:/";

        }


    }




